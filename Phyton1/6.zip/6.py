son = int(input("ikki xonali son kiriting:\n"))
print("O'nliklar xonasidagi raqam = ", son//10)
print("Birliklar xonasidagi son teng = ", son%10)
